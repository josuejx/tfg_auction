<?php

	// CONFIGURACIÓN BASE DE DATOS MYSQL
	$servername = "akraineroot.mysql.db";
	$username = "akraineroot";
	$password = "Akra2014";
	
	// BASE DE DATOS
	$dbname = "akraineroot";

	// ACCESO USUARIOS (si está vacío funciona sin usuarios)
	$usuarios = array();

	
	// TABLAS Y SU CLAVE
	$tablas = array();
	$tablas["usuarios"] = "_id";
	$tablas["productos"] = "_id";
	$tablas["categorias"] = "_id";
	$tablas["puja"] = "_id";
	$tablas["archivado"] = "_id";